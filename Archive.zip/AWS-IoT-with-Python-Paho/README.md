# AWS-IoT-with-Python-Paho

For Details please refer to following link -

https://iotbytes.wordpress.com/mqtt-with-aws-iot-using-python-and-paho/
